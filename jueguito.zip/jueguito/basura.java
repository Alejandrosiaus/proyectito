import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class basura here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class basura extends Actor
{
    /**
     * Act - do whatever the basura wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        // Add your action code here.
    }
    public basura()
    {
        GreenfootImage myImage = getImage();
        myImage.scale(200, 200);
    }
}
